dot -o TreeStruct.png -T png example1.dot
